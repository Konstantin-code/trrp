﻿using SuperSocket.SocketBase;
using SuperWebSocket;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;
using ClientServerMessage;
using Newtonsoft.Json;
using Npgsql;



namespace Server
{
    class Server
    {
        private static WebSocketServer wsServer;
        private static RSACryptoServiceProvider RSA;
        private static Dictionary<string, DESCryptoServiceProvider> dictionaryDES;

        public static void Main(string[] args)
        {
            RSA = new RSACryptoServiceProvider();
            dictionaryDES = new Dictionary<string, DESCryptoServiceProvider>();

            wsServer = new WebSocketServer();
            int port = 8088;
            wsServer.Setup(port);
            wsServer.NewSessionConnected += WsServer_NewSessionConected;
            wsServer.NewDataReceived += WsServer_NewDataReceived;
            wsServer.SessionClosed += WsServer_SessionClosed;
            wsServer.Start();
            Console.WriteLine("Сервер работает через порт " + port + ". нажмите ENTER, чтобы выйти...");
            ConsoleKeyInfo keyInfo = Console.ReadKey();
            while (keyInfo.Key != ConsoleKey.Enter)
                keyInfo = Console.ReadKey();
            wsServer.Stop();
        }

        private static void WsServer_SessionClosed(WebSocketSession session, CloseReason value)
        {
            var id = session.SessionID;
            Console.WriteLine("Сессия закрыта: " + id);
        }

        private static void WsServer_NewDataReceived(WebSocketSession session, byte[] value)
        {
            Console.WriteLine("Получены новые данные");
            if (!dictionaryDES.ContainsKey(session.SessionID))
            {
                Console.WriteLine("Попытка создания DES для сессии: " + session.SessionID);
                var byteConf = RSA.Decrypt(value, true);
                Console.WriteLine("Расшифровка RSA: " + session.SessionID);
                var serializeConf = Encoding.UTF8.GetString(byteConf);
                DESConfig desConfig = (DESConfig)JsonConvert.DeserializeObject(serializeConf, typeof(DESConfig));
                Console.WriteLine("Преобразован DES Config: " + session.SessionID);
                var DES = new DESCryptoServiceProvider();
                DES.Key = desConfig.key;
                DES.IV = desConfig.IV;

                Console.WriteLine("DES создан: " + session.SessionID);
                Console.WriteLine("Тип экземпляров класса DES: " + DES.GetType());
                dictionaryDES.Add(session.SessionID, DES);
                session.Send("Get");
                return;
            }

            var message = Received(session.SessionID, value);
            switch (message.type)
            {
                case TypeMessage.SendMes:
                    Console.WriteLine("Отправлено от: " + session.SessionID);
                    Console.WriteLine("Сообщение: " + message.value);
                    break;
                case TypeMessage.SendData:
                    
                    ElementDataBase element = (ElementDataBase)JsonConvert.DeserializeObject<ElementDataBase>(message.value);
                    Console.WriteLine("Данные отправлены");

                    
                    using (NpgsqlConnection conn = new NpgsqlConnection("Host=localhost; Port=5433; Database=lab2; Username=postgres; Password=111"))
                         {
                        conn.Open();

                        NpgsqlCommand cmd = new NpgsqlCommand(
                            @"declare @count int
                        select @count = count(id_trass) FROM trass where id_trass=@id_trass
                        if (@count=0)
                        insert into trass VALUES(@id_trass, @name_trass, @distance)
                        select @count = count(id_ski_firm) FROM ski_firm where id_ski_firm=@id_firm_ski
                        if (@count=0)
                        insert into ski_firm VALUES(@id_firm_ski, @name_ski_firm)
                        select @count = count(id_country) FROM country where id_country=@id_country
                        if (@count=0)
                        insert into country VALUES(@id_country, @contry_name)                        
                        select @count = count(id_sportsmen) FROM sportsmen where id_sportsmen=@id_sportsmen
                        if (@count=0)
                        insert into racer VALUES (@id_sportsmen,@name_sportsmen, @id_country, @id_ski_firm)                      
                        select @count = count(id_result) FROM result where id_result=@result_id
                        if (@count=0)
                        insert into result VALUES(@id, @result_id, @id_sportsmen, @id_trass, @time, @shooting)",
                        conn);
                        cmd.Parameters.AddWithValue("@id", element.id);
                        cmd.Parameters.AddWithValue("@id_sportsmen", element.id_sportsmen);
                        cmd.Parameters.AddWithValue("@name_sportsmen", element.name_sportsmen);
                        cmd.Parameters.AddWithValue("@id_ski_firm", element.id_ski_firm);
                        cmd.Parameters.AddWithValue("@name_ski_firm", element.name_ski_firm);
                        cmd.Parameters.AddWithValue("@id_country", element.id_country);
                        cmd.Parameters.AddWithValue("@name_country", element.name_country);
                        cmd.Parameters.AddWithValue("@time", element.time);
                        cmd.Parameters.AddWithValue("@shooting", element.shooting);
                        cmd.Parameters.AddWithValue("@result_id", element.result_id);
                        cmd.Parameters.AddWithValue("@id_trass", element.id_trass);
                        cmd.Parameters.AddWithValue("@name_trass", element.name_trass);
                        cmd.Parameters.AddWithValue("@distance", element.distance);
                        cmd.ExecuteNonQuery();
                    }
                    
                    
                    break;
                    
                default:
                    session.Close(CloseReason.ProtocolError);
                    break;
            }

        }



        private static void WsServer_NewSessionConected(WebSocketSession session)
        {
            var id = session.SessionID;
            Console.WriteLine("Подключена новая сессия: " + id);
            session.Send(RSA.ToXmlString(false));
            Console.WriteLine("Отправлен публичный ключ RSA: " + id);
        }

        private static StandartMessage Received(string sessionId, byte[] value)
        {
            var DES = dictionaryDES[sessionId];
            using (var decrypt = DES.CreateDecryptor())
            {
                var byteMes = decrypt.TransformFinalBlock(value, 0, value.Length);
                var serializeMes = Encoding.UTF8.GetString(byteMes);
                var message = JsonConvert.DeserializeObject(serializeMes, typeof(StandartMessage));
                return (StandartMessage)message;
            }
            throw new Exception();
        }
    }
    
}
