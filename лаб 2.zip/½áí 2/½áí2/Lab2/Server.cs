﻿using SuperSocket.SocketBase;
using SuperWebSocket;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
using ClientServerMessage;
using Newtonsoft.Json;

namespace Server
{
    class Server
    {
        private static WebSocketServer wsServer;
        private static RSACryptoServiceProvider RSA;
        private static Dictionary<string, DESCryptoServiceProvider> dictionaryDES;

        public static void Main(string[] args)
        {
            RSA = new RSACryptoServiceProvider();
            dictionaryDES = new Dictionary<string, DESCryptoServiceProvider>();

            wsServer = new WebSocketServer();
            int port = 8088;
            wsServer.Setup(port);
            wsServer.NewSessionConnected += WsServer_NewSessionConected;
            wsServer.NewMessageReceived += WsServer_NewMessageReceived; ;
            wsServer.NewDataReceived += WsServer_NewDataReceived;
            wsServer.SessionClosed += WsServer_SessionClosed;
            wsServer.Start();
            Console.WriteLine("Server is running on port " + port + ". Press ENTER to exit...");
            Console.ReadKey();
            wsServer.Stop();
        }

        private static void WsServer_SessionClosed(WebSocketSession session, CloseReason value)
        {
            var id = session.SessionID;
            Console.WriteLine("SessionClosed: " + id);
        }

        private static void WsServer_NewDataReceived(WebSocketSession session, byte[] value)
        {
            Console.WriteLine("NewDataReceived");
            if (!dictionaryDES.ContainsKey(session.SessionID))
            {
                Console.WriteLine("Try Create DES For Session: " + session.SessionID);
                var byteConf = RSA.Decrypt(value, true);
                Console.WriteLine("RSA Decrypted: " + session.SessionID);
                var serializeConf = Encoding.UTF8.GetString(byteConf);
                DESConfig desConfig = (DESConfig)JsonConvert.DeserializeObject(serializeConf, typeof(DESConfig));
                Console.WriteLine("DES Config Converted: " + session.SessionID);
                var DES = new DESCryptoServiceProvider();
                DES.Key = desConfig.key;
                DES.IV = desConfig.IV;
                Console.WriteLine("DES Created: " + session.SessionID);
                dictionaryDES.Add(session.SessionID, DES);
                session.Send("Get");
                return;
            }

            var message = Received(session.SessionID, value);
            switch (message.type)
            {
                case TypeMessage.SendMes:
                    Console.WriteLine("Send from: " + session.SessionID);
                    Console.WriteLine("message: " + message.value);
                    break;
                case TypeMessage.SendData:
                    Console.WriteLine("Send from: " + session.SessionID);
                    ElementDataBase element = (ElementDataBase)JsonConvert.DeserializeObject<ElementDataBase>(message.value);
                    Console.WriteLine(string.Format("message: {0}, {1}, {2}, {3}, {4}, {5}, {6}, {7}, {8}, {9}, {10}, {11}", element.ID_Users, element.Login, element.Password, element.ID_Complexity, element.Name_Complexity, element.ID_Theme, element.Name_Theme, element.ID_Question, element.Question, element.Rigth_Answer, element.ID, element.User_Answer));
                    using (SqlConnection conn = new SqlConnection("Server=LAPTOP;Database=Lab2; Integrated Security=true"))
                    {
                        conn.Open();
                        using (var comm = new SqlCommand(string.Format(
                            @"declare @count int
                        select @count = count(ID) FROM Users where ID={0}
                        if (@count=0)
                        insert into Users VALUES ({0},'{1}','{2}')
                        select @count = count(ID) FROM Complexity where ID={3}
                        if (@count=0)
                        insert into Complexity VALUES({3}, '{4}')
                        select @count = count(ID) FROM Theme where ID={5}
                        if (@count=0)
                        insert into Theme VALUES({5}, '{6}')
                        select @count = count(ID) FROM Question where ID={7}
                        if (@count=0)
                        insert into Question VALUES({7}, '{8}', {3}, {5}, '{9}')
                        select @count = count(ID) FROM AnswerUser where ID={10}
                        if (@count=0)
                        insert into AnswerUser VALUES({10}, {0}, {7}, '{11}')", element.ID_Users, element.Login, element.Password, element.ID_Complexity, element.Name_Complexity, element.ID_Theme, element.Name_Theme, element.ID_Question, element.Question, element.Rigth_Answer, element.ID, element.User_Answer),
                            conn))
                        {
                            comm.ExecuteReader().Read();
                        }
                    }
                    break;
                default:
                    session.Close(CloseReason.ProtocolError);
                    break;
            }
        }

        private static void WsServer_NewMessageReceived(WebSocketSession session, string value)
        {
            Console.WriteLine("NewMessageReceived " + value);
            if (value == "Hello server")
                foreach (var sessioni in wsServer.GetAllSessions())
                {
                    Console.WriteLine("Name: " + session.Config.Name);
                    sessioni.Send("Hello client");
                }
        }

        private static void WsServer_NewSessionConected(WebSocketSession session)
        {
            var id = session.SessionID;
            Console.WriteLine("NewSessionConected: " + id);
            session.Send(RSA.ToXmlString(false));
            Console.WriteLine("Send public key RSA: " + id);
        }

        private static StandartMessage Received(string sessionId, byte[] value)
        {
            var DES = dictionaryDES[sessionId];
            using (var decrypt = DES.CreateDecryptor())
            {
                var byteMes = decrypt.TransformFinalBlock(value, 0, value.Length);
                var serializeMes = Encoding.UTF8.GetString(byteMes);
                var message = JsonConvert.DeserializeObject(serializeMes, typeof(StandartMessage));
                return (StandartMessage)message;
            }
            throw new Exception();
        }
    }
}
