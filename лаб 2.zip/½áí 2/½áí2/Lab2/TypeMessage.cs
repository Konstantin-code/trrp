﻿namespace ClientServerMessage
{
    public enum TypeMessage
    {
        SendMes,
        SendData
    }
}
