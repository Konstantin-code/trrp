﻿namespace ClientServerMessage
{
    public struct StandartMessage
    {
        public TypeMessage type;
        public string value;

        public StandartMessage(string _value, TypeMessage _typeMessage)
        {
            value = _value;
            type = _typeMessage;
        }
    }
}
